package com.example.searchApp.search;

import java.util.*;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class SearchService {

	private final RabbitTemplate rabbitTemplate;

	public SearchService(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
		}

	public List<Listing> getSearchResults(String searchKey)
	{
		rabbitTemplate.convertAndSend("search-products-exchange", "{\"from\":\"Search\",\"method\":\"getListings\",\"searchKey\":\""+searchKey+"\"}");
		//for setting up rabbitMQ later

		List<Listing> test = List.of(
				new Listing("1",20000,"car"),
				new Listing("2",1000,"bike"),
				new Listing("3",3000,"tv"),
				new Listing("4",9000,"boat"),
				new Listing("5",7000,"mobile"),
				new Listing("6",6000,"laptop")

				);
		
		List<Listing> results = new ArrayList<Listing>();
		
		System.out.println("Searching for: " + searchKey);
		
		if(searchKey.equals("")) {
			return test;
		}
		else
		{
			for (int i = 0; i < test.size(); i++) {
				if(test.get(i).title.contains(searchKey))
				{
					results.add(test.get(i));
				}
			}
		}
		return results;
	}
}
