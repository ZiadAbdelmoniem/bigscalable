package com.guc.merch.models.listing;

public enum ListingStatus {
    ONLINE, OFFLINE, SOLD
}